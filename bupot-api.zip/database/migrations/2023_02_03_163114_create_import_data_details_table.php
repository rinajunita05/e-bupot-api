<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('import_data_details', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('import_data_id');
            $table->foreign('import_data_id')->references('id')->on('import_data')->onDelete('cascade');
            $table->string("tgl_pemotongan");
            $table->string("penerima_penghasilan");
            $table->string("npwp");
            $table->string("nik");
            $table->string("nama_penerima");
            $table->string("qq");
            $table->string("no_hp");
            $table->string("kode_objek_pajak");
            $table->string("penandatangan_bp");
            $table->string("penandatangan_menggunakan");
            $table->string("npwp_penandatangan");
            $table->string("nik_penandatangan");
            $table->string("namapenandatangan_sesuai_nik");
            $table->string("penghasilan_bruto");
            $table->string("fasilitas");
            $table->string("no_skb");
            $table->string("no_aturandtp");
            $table->string("no_suketpp23");
            $table->string("fasilitaspph_berfaspph_lainnya");
            $table->string("ib_diproses");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('import_data_details');
    }
};
